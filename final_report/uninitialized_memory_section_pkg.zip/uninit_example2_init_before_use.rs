fn main() {
    let x: i32;
    x = 10;                       // Line 3: initialized before use
    println!("{}", x);            // Line 4: OK
}
