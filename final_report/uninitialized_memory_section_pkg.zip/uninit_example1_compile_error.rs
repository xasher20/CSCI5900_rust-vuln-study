fn main() {
    let x: i32;                  // Line 2: declared but not initialized
    // println!("{}", x);        // Line 3: COMPILE ERROR — use of possibly-uninitialized `x`
}
